
import scr from '../assets/scr.png'

function ImageComponent () {
    return <img src={scr} width="360" height="360" alt="" /> 
}
export default ImageComponent