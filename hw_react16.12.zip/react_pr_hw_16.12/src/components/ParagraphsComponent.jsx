

function ParagraphsComponent () {
    return (
        <>
        <h1>king gizzard and the lizard wizard</h1>
        <p>Lorem ips.</p>
        <h2>Live in Madrid</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Culpa omnis ipsum quae, sed hic deleniti quo esse alias magni reprehenderit voluptas reiciendis repudiandae architecto beatae corrupti dicta accusamus et nihil!</p>
        <h3>Live in London</h3>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officia dignissimos maxime mollitia magni autem iste architecto voluptatum quisquam nobis numquam aperiam, odit, minima eaque, inventore repellat laudantium impedit quam corporis. Rerum repellat deserunt eius at odit sapiente, quod omnis aut?</p>
        <h4>Live in Berlin</h4>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptates, illum est in nihil corporis asperiores inventore modi autem dolorem! Enim.</p>
          
        </>
    )
}
export default ParagraphsComponent